// $('.jquery-background-video').bgVideo({fadeIn: 2000});
$('.my-background-video').bgVideo({fadeIn: 2000});